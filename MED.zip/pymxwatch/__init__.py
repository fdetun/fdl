__all__ = ["config", "patterns", "state", "notifier",
           "emailer", "filesink", "tailer", "watcher"]
__version__ = "0.1.0"
