from abc import ABC, abstractmethod
from typing import Sequence

class Notifier(ABC):
    @abstractmethod
    def send(self, subject: str, body: str): ...

class Fanout(Notifier):
    """Broadcasts the message to all sinks; continues on individual failure."""
    def __init__(self, sinks: Sequence[Notifier]): self.sinks = sinks
    def send(self, subject: str, body: str):
        for n in self.sinks:
            try:
                n.send(subject, body)
            except Exception as exc:
                print(f"[pymxwatch] {n.__class__.__name__} failed: {exc}")
