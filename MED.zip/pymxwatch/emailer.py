import os, ssl, smtplib
from email.message import EmailMessage
from .config import SMTPSettings
from .notifier import Notifier

class Emailer(Notifier):
    def __init__(self, cfg: SMTPSettings):
        self.cfg   = cfg
        self.user  = os.getenv(cfg.user_env)
        self.passw = os.getenv(cfg.pass_env)

    def send(self, subject: str, body: str):
        if not (self.user and self.passw):
            raise RuntimeError("SMTP credentials not set in environment")

        msg = EmailMessage()
        msg["Subject"], msg["From"] = subject, self.user
        msg["To"] = ", ".join(self.cfg.to)
        msg.set_content(body)

        with smtplib.SMTP_SSL(self.cfg.host,
                              self.cfg.port,
                              context=ssl.create_default_context()) as s:
            s.login(self.user, self.passw)
            s.send_message(msg)
