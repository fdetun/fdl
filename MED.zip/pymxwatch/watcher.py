#!/usr/bin/env python3
import argparse, time
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events    import FileSystemEventHandler

from .config   import load
from .state    import JsonStore
from .tailer   import scan_file
from .notifier import Fanout
from .filesink import FileSink
from .emailer  import Emailer

# ── CLI override ─────────────────────────────────────────────────────
cli = argparse.ArgumentParser()
cli.add_argument("--config", default="/opt/pymxwatch/config.yml")
cli.add_argument("--no-email", action="store_true",
                 help="disable e-mail regardless of config.yml")
args = cli.parse_args()

cfg   = load(Path(args.config))
store = JsonStore(Path("/opt/pymxwatch/state.json"))

sinks = [FileSink()]                          # always keep local copy
if cfg.smtp.enabled and not args.no_email:    # conditional e-mail
    sinks.append(Emailer(cfg.smtp))
notifier = Fanout(sinks)

# ── Watchdog handler ─────────────────────────────────────────────────
class Handler(FileSystemEventHandler):
    def on_modified(self, ev):
        if ev.is_directory: return
        if not Path(ev.src_path).match(cfg.glob_pattern): return
        p = Path(ev.src_path)
        new_off, hits = scan_file(p, store.get_offset(str(p)))
        if hits:
            notifier.send(f"[pymx] {p.name} error", "\n".join(hits[-40:]))
        store.update(str(p), new_off)

    on_deleted = on_moved = lambda self, ev: store.drop(ev.src_path)

# ── bootstrap + main loop ────────────────────────────────────────────
def bootstrap(handler: Handler):
    for fp in Path(cfg.log_dir).glob(cfg.glob_pattern):
        handler.on_modified(type("E", (), {"is_directory": False,
                                           "src_path": str(fp)}))

def main():
    h, obs = Handler(), Observer()
    obs.schedule(h, cfg.log_dir, recursive=False)
    obs.start(); bootstrap(h)

    try:
        while True:
            time.sleep(30)
            store.purge_idle(cfg.idle_minutes)
            store.save()
    except KeyboardInterrupt:
        pass
    finally:
        obs.stop(); obs.join(); store.save()

if __name__ == "__main__":
    main()
