from pathlib import Path
from typing import Tuple, List
from .patterns import iter_matches

def scan_file(path: Path, offset: int) -> Tuple[int, List[str]]:
    """
    Return new_offset, list_of_alert_lines (may be empty).
    Each alert line already contains its rule tag.
    """
    hits = []
    with path.open(errors="ignore") as f:
        f.seek(offset)
        for line in f:
            names = iter_matches(line)
            if names:
                hits.append(f"[{names[0]}] {line.rstrip()}")
        return f.tell(), hits
