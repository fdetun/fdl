import re
from typing import NamedTuple, List

class Rule(NamedTuple):
    name: str
    regex: re.Pattern

_RULES: List[Rule] = [
    Rule("pymx_error_tag", re.compile(r"<ERROR>")),
    Rule("traceback",      re.compile(r"Traceback \(most recent call last\):")),
    Rule("import_error",   re.compile(r"No module named \S+")),
    Rule("name_error",     re.compile(r"NameError:\s+global name .+ is not defined")),
    Rule("permission_denied", re.compile(r"\[Errno 13\] Permission denied")),
    Rule("file_not_found",    re.compile(r"\[Errno 2\] No such file or directory")),
    Rule("valuation_error",   re.compile(r"ILN? VALORACION DE HLM1")),
]

def iter_matches(line: str):
    """Return list of rule names that match the line (usually 0 or 1)."""
    return [r.name for r in _RULES if r.regex.search(line)]
