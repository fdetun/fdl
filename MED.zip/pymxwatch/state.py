import json, tempfile, shutil, datetime as dt
from pathlib import Path
from typing import Dict, Any

FileState = Dict[str, Dict[str, Any]]  # path → {"offset": int, "last": iso}

class JsonStore:
    def __init__(self, path: Path):
        self.path = path
        self.data: FileState = self._load()

    # ── public API ──────────────────────────────────────────────────────
    def get_offset(self, path: str) -> int:
        return self.data.get(path, {}).get("offset", 0)

    def update(self, path: str, offset: int):
        self.data[path] = {"offset": offset,
                           "last": dt.datetime.utcnow().isoformat()}

    def drop(self, path: str):
        self.data.pop(path, None)

    def purge_idle(self, minutes: int):
        cutoff = dt.datetime.utcnow() - dt.timedelta(minutes=minutes)
        for p, meta in list(self.data.items()):
            if dt.datetime.fromisoformat(meta["last"]) < cutoff:
                self.drop(p)

    def save(self):
        tmp = tempfile.NamedTemporaryFile("w", delete=False,
                                          dir=self.path.parent)
        json.dump(self.data, tmp)
        tmp.flush(); shutil.move(tmp.name, self.path)

    # ── private ────────────────────────────────────────────────────────
    def _load(self):
        try:
            return json.loads(self.path.read_text())
        except FileNotFoundError:
            return {}
