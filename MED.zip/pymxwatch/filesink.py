from pathlib import Path
import json, datetime as dt, tempfile, shutil
from .notifier import Notifier

class FileSink(Notifier):
    """Appends every alert to alerts.jsonl (one JSON object per line)."""
    def __init__(self, path: Path = Path("../alerts.jsonl")):
        self.path = path

    def send(self, subject: str, body: str):
        entry = {
            "ts":   dt.datetime.utcnow().isoformat(timespec="seconds"),
            "subj": subject,
            "body": body,
        }
        tmp = tempfile.NamedTemporaryFile("w", delete=False,
                                          dir=self.path.parent)
        json.dump(entry, tmp); tmp.write("\n")
        tmp.flush(); shutil.move(tmp.name, self.path)
