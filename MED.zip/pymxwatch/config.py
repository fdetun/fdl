from pathlib import Path
import yaml, pydantic

class SMTPSettings(pydantic.BaseModel):
    enabled: bool = True
    host: str
    port: int
    user_env: str
    pass_env: str
    to: list[str]

class AppConfig(pydantic.BaseModel):
    log_dir: Path
    glob_pattern: str
    idle_minutes: int = 30
    smtp: SMTPSettings

def load(path: Path = Path("../config.yml")) -> AppConfig:
    return AppConfig.model_validate_yaml(path.read_text())
